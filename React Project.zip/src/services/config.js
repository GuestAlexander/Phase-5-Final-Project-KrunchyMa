export const BASE_API_URL = `http://localhost:5000/api/v1`;
