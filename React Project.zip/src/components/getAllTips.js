import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  retrieveTIPS,
} from "../actions/tips";
import { useNavigate  } from 'react-router-dom';

const TipsList = () => {
  const Tips = useSelector(state => state.tips);
  const dispatch = useDispatch();
  let navigate = useNavigate();

  useEffect(() => {
    dispatch(retrieveTIPS());
  }, []);

  // const getByIdTips = (id) => {
  //   navigate(`/update/${id}`);
  // };

  return (
    <div className="list row">
      <div className="col-md-6">
        <h4>Tips List</h4>
        <ul className="list-group">
          {Tips &&
            Tips.map((tip, index) => (
              <li
                className={"list-group-item" }
                key={index}
              >
                {tip.desc}
                
                  {/* <button onClick={() => getByIdTips(tip.id)}  className="btn btn-primary right"> Update</button> */}
              </li>
              
            ))}
        </ul>
      </div>
    </div>
  );
};

export default TipsList;