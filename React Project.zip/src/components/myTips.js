import React, {useState, useEffect} from "react";
import {useDispatch, useSelector} from "react-redux";
import {
    userTIPS,
    findTIPSByID,
} from "../actions/tips";
import {useNavigate} from 'react-router-dom';

const MyTipsList = () => {
    const Tips = useSelector(state => state.tips);

    const dispatch = useDispatch();
    let navigate = useNavigate();

    useEffect(() => {
        dispatch(userTIPS());
    }, []);

    const getByIdTips = (id) => {
        navigate(`/update/${id}`);
    };

    return (
        <div className="list row">
            <div className="col-md-6">
                <h4>My Tips</h4>
                <ul className="list-group">
                    {Tips &&
                        Tips.map((tip, index) => (
                            <li
                                className={"list-group-item"}
                                key={index}
                            >
                                {tip.desc}

                                <button onClick={() => getByIdTips(tip.id)} className="btn btn-primary right"> Update
                                </button>
                            </li>

                        ))}
                </ul>
            </div>
        </div>
    );
};

export default MyTipsList;
